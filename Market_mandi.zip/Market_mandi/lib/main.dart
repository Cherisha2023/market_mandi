import 'package:flutter/material.dart';

void main() {
  runApp(MarketMandiApp());
}

class MarketMandiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF2A5D50),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Color(0xFF2A5D50),
          secondary: Colors.orange,
        ),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  String _selectedLanguage = 'English';

  final Map<String, Map<String, String>> _translations = {
    'English': {
      'appTitle': 'Market Mandi',
      'aadhaarID': 'Aadhaar ID',
      'instruction': 'Please type in your Aadhaar ID',
      'login': 'Login',
      'selectLanguage': 'Select Language',
      'error': 'Please enter a valid 12-digit Aadhaar ID',
    },
    'Tamil': {
      'appTitle': 'மார்கெட் மண்டி',
      'aadhaarID': 'ஆதார் ஐடி',
      'instruction': 'உங்கள் ஆதார் ஐடியை உள்ளிடவும்',
      'login': 'உள்நுழையவும்',
      'selectLanguage': 'மொழியை தேர்ந்தெடுங்கள்',
      'error': 'சரியான 12-எண்ண ஆதார் ஐடியை உள்ளிடவும்',
    },
  };

  final TextEditingController _aadhaarController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'assets/images/backgroundd.jpg',
              fit: BoxFit.cover,
            ),
          ),
          // Content
          Center(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 30),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Colors.black54],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DropdownButton<String>(
                    value: _selectedLanguage,
                    icon: Icon(Icons.language, color: Colors.white),
                    dropdownColor: Colors.green.shade700,
                    items: ['English', 'Tamil'].map((String language) {
                      return DropdownMenuItem<String>(
                        value: language,
                        child: Text(
                          _translations[language]!['selectLanguage']!,
                          style: TextStyle(color: Colors.white),
                        ),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedLanguage = newValue!;
                      });
                    },
                  ),
                  SizedBox(height: 20),
                  CircleAvatar(
                    radius: 70,
                    backgroundImage: AssetImage('assets/farmer.png'),
                    backgroundColor: Colors.transparent,
                  ),
                  SizedBox(height: 20),
                  Text(
                    _translations[_selectedLanguage]!['appTitle']!,
                    style: TextStyle(
                      fontSize: 28,
                      color: Colors.orange,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    _translations[_selectedLanguage]!['aadhaarID']!,
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    _translations[_selectedLanguage]!['instruction']!,
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white60,
                    ),
                  ),
                  SizedBox(height: 20),
                  TextField(
                    controller: _aadhaarController,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                      prefixIcon: Icon(Icons.credit_card, color: Colors.green),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 30),
                  ElevatedButton.icon(
                    onPressed: () {
                      String enteredAadhaar = _aadhaarController.text;
                      if (enteredAadhaar.length == 12 &&
                          RegExp(r'^[0-9]+$').hasMatch(enteredAadhaar)) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProfileScreen(
                              aadhaarID: enteredAadhaar,
                            ),
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(_translations[_selectedLanguage]!['error']!),
                          ),
                        );
                      }
                    },
                    icon: Icon(Icons.login, color: Colors.indigo),
                    label: Text(
                      _translations[_selectedLanguage]!['login']!,
                      style: TextStyle(
                        color: Colors.indigo,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final String aadhaarID;

  ProfileScreen({required this.aadhaarID});

  // Method to get profile details based on Aadhaar ID
  Map<String, dynamic> getProfile(String aadhaarID) {
    Map<String, Map<String, dynamic>> profiles = {
      '619053589612': {
        'name': 'Ramalakshmi M',
        'dob': '25-11-2004',
        'gender': 'Female',
        'address': '106, F Chinnakadai Street, Mattakadai, Tuticorin - 628001',
        'phone': '9789286549',
      },
      '264278204158': {
        'name': 'Ragul M',
        'dob': '01-06-2005',
        'gender': 'Male',
        'address': 'Teachers Colony, 2nd Cross Street, Nanganallur, Chennai - 91',
        'phone': '9962499023',
      },
    };

    return profiles[aadhaarID] ?? {
      'name': 'Unknown',
      'dob': 'Unknown',
      'gender': 'Unknown',
      'address': 'Unknown',
      'phone': 'Unknown',
    };
  }

  @override
  Widget build(BuildContext context) {
    // Fetch the profile details based on Aadhaar ID
    var profile = getProfile(aadhaarID);

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: Color(0xFF2A5D50),
      ),
      body: Center(
        child: Card(
          margin: EdgeInsets.all(16.0),
          elevation: 8.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.green,
                  child: Icon(
                    Icons.person,
                    size: 50,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 20),
                _buildProfileField(Icons.person, 'Name', profile['name']),
                _buildProfileField(Icons.calendar_today, 'Date of Birth', profile['dob']),
                _buildProfileField(Icons.transgender, 'Gender', profile['gender']),
                _buildProfileField(Icons.home, 'Address', profile['address']),
                _buildProfileField(Icons.phone, 'Phone', profile['phone']),
                SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RoleSelectionScreen(),
                      ),
                    );
                  },
                  icon: Icon(Icons.arrow_forward, color: Colors.indigo),
                  label: Text(
                    'Proceed to Role Selection',
                    style: TextStyle(
                      color: Colors.indigo,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileField(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Colors.green),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              '$label: $value',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}

class RoleSelectionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Your Role'),
        backgroundColor: Color(0xFF2A5D50),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FarmerScreen(),
                  ),
                );
              },
              child: Text('Farmer'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VendorScreen(),
                  ),
                );
              },
              child: Text('Vendor'),
            ),
          ],
        ),
      ),
    );
  }
}

class FarmerScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Farmer Screen'),
        backgroundColor: Color(0xFF2A5D50),
      ),
      body: Center(child: Text('Farmer Screen Content')),
    );
  }
}

class VendorScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Vendor Screen'),
        backgroundColor: Color(0xFF2A5D50),
      ),
      body: Center(child: Text('Vendor Screen Content')),
    );
  }
}
