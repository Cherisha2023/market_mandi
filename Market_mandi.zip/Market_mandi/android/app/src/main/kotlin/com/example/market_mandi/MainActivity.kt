package com.example.market_mandi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
